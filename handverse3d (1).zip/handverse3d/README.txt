HANDVERSE 3D — Particle Playground

REQUISITOS
- Navegador moderno (Chrome, Edge, Safari actualizado).
- Conexión a internet para cargar Three.js y MediaPipe desde CDN.
- Cámara para activar el control por manos.

CÓMO EJECUTAR
Opción recomendada (computador):
1. Descomprime handverse3d.zip.
2. Abre una terminal dentro de la carpeta handverse3d.
3. Ejecuta: python -m http.server 8000
4. Entra a: http://localhost:8000
5. Pulsa “Activar control con manos” y concede permiso de cámara.

También puedes publicar la carpeta en GitHub Pages, Netlify o Vercel. La cámara requiere HTTPS o localhost; abrir index.html directamente puede impedir el acceso a la cámara.

FUNCIONES
- Render 3D con Three.js y shader de partículas aditivas.
- Figuras: galaxia, corazón, esfera, flor, Saturno, mariposa, ADN, onda y supernova.
- Control de cantidad, tamaño, energía y color.
- Detección de mano con MediaPipe Hands; gestos aproximados para expansión/contracción y atracción.
- Rotación por arrastre, zoom con rueda y pantalla completa.

NOTAS
Es un prototipo funcional inicial. La detección de gestos depende de la iluminación, la cámara y el navegador. En móviles de gama baja, reduce la cantidad de partículas. No guarda ni envía imágenes de cámara a un servidor propio; el procesamiento de detección se ejecuta en el navegador con las librerías cargadas desde CDN.
